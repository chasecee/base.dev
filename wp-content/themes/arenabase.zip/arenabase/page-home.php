<?php
/*
Template Name: Home Page
Description: No container wrapping this page, so you can have full width elements.
*/

get_header(); ?>


<?php while ( have_posts() ) : the_post(); ?>

<section id="signup" class=" bg main" style="background-image:url(<?php the_post_thumbnail_url( 'full' ); ?>);" />
    <div class="container">
      <i class="fa fa-camera-retro fa-lg"></i> fa-lg
<i class="fa fa-camera-retro fa-2x"></i> fa-2x
<i class="fa fa-camera-retro fa-3x"></i> fa-3x
<i class="fa fa-camera-retro fa-4x"></i> fa-4x
<i class="fa fa-camera-retro fa-5x"></i>
    </div>
</section>







<?php endwhile; // end of the loop. ?>

<?php get_footer(); ?>
